package com.techface.gold.scheme.network;

import com.techface.gold.scheme.model.ProductList;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiClient {


    // Get the Product Details
    @GET("/bins/zlu6c")
    Call<List<ProductList>>getProductdetail();

}
