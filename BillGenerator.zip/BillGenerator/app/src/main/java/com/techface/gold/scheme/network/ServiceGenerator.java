package com.techface.gold.scheme.network;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.techface.gold.scheme.Helper.Constants;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ServiceGenerator {

    private static Gson gson = new GsonBuilder().setLenient()
            .serializeNulls()
            .create();

    private static final String BASE_URL = Constants.SERVERURL;

    private static Retrofit.Builder  builder = new Retrofit.Builder().
            baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(gson));

    private static Retrofit retrofit = builder.build();


    private static HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor()
            .setLevel(HttpLoggingInterceptor.Level.BODY);

    private static OkHttpClient.Builder httpClient = new OkHttpClient.Builder()
            .connectTimeout(50, TimeUnit.SECONDS)
            .readTimeout(50,TimeUnit.SECONDS)
            .writeTimeout(50,TimeUnit.SECONDS);


    public static <S> S createService(Class<S> serviceClass){
        if (!httpClient.interceptors().contains(loggingInterceptor)){
            httpClient.addInterceptor(loggingInterceptor);
            builder.client(httpClient.build());
            retrofit = builder.build();
        }
        return retrofit.create(serviceClass);
    }
}
