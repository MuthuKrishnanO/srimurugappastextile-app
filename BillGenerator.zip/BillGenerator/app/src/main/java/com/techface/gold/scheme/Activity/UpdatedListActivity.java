package com.techface.gold.scheme.Activity;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.design.widget.AppBarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.techface.gold.scheme.Adapter.SugarQuantityAdapter;
import com.techface.gold.scheme.DialogueFragment.PaymentFragment;
import com.techface.gold.scheme.R;
import com.techface.gold.scheme.model.ProductList;

import java.io.Serializable;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static android.widget.LinearLayout.VERTICAL;

public class UpdatedListActivity extends AppCompatActivity {

    @BindView(R.id.mRecylerView)
    RecyclerView mRecylerView;

    @BindView(R.id.bilpay)
    Button mPayView;

    @BindView(R.id.toolbar)
    Toolbar mToolbar;


    @BindView(R.id.toolbar1)
    AppBarLayout mAppBarLayout;


    private  List<ProductList.product> mList;
    private SugarQuantityAdapter mSugarQuantityAdapter;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updated_list);
        ButterKnife.bind(this);

        mToolbar.setBackgroundColor(Color.parseColor("#ffffff"));
        mToolbar.setTitleTextColor((Color.parseColor("#000000")));





        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Make toolbar show navigation button (i.e back button with arrow icon)

        mToolbar.setNavigationIcon(R.drawable.ic_arrow);

     //   getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow);
//        if (getSupportActionBar() != null) {
//
//            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
//            getSupportActionBar().setTitle("cart");
//
//
//        }
      mList = (List<ProductList.product>) getIntent().getSerializableExtra("selectedList");
      LoadSelectedList();


      mPayView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String mTotal=String.valueOf(mPayView.getText());
            PaymentFragment bottomSheetFragment1 = new PaymentFragment().newInstance(mTotal,mList);
            bottomSheetFragment1.show(getSupportFragmentManager(), bottomSheetFragment1.getTag());
//        Intent intent=new Intent(UpdatedListActivity.this,UpdatedListActivity.class);
//        intent.putExtra("printerlist", (Serializable) mList);
//        startActivity(intent);
        }
    });


    }

    private void LoadSelectedList() {

        LinearLayoutManager manager = new LinearLayoutManager(getApplicationContext());

        mRecylerView.setLayoutManager(manager);
        viewTotal(mList);

        mSugarQuantityAdapter =new SugarQuantityAdapter(UpdatedListActivity.this,mList, new SugarQuantityAdapter.IMethodCaller() {
            @Override
            public void grandList(List<ProductList.product> items) {
                viewTotal(items);
            }
        });

        DividerItemDecoration decoration = new DividerItemDecoration(getApplicationContext(), VERTICAL);
        mRecylerView.addItemDecoration(decoration);
        mRecylerView.setAdapter(mSugarQuantityAdapter);




    }

    private void viewTotal(List<ProductList.product> items) {
    int sumTotal=0;
    if(items.size()!=0) {
        for (int i = 0; i < items.size(); i++) {
            sumTotal = sumTotal + items.get(i).getmTotal();
        }

        mPayView.setText("TOTAL ₹"+String.valueOf(sumTotal));
    }
    else {
        onBackPressed();
    }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();

            return true;
        }


        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(mList!=null && mList.size()>0) {
            Intent intent1 = new Intent(UpdatedListActivity.this, HomeActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent1.putExtra("cancellist", (Serializable) mList);
            startActivity(intent1);
        }else {
            Intent intent1 = new Intent(UpdatedListActivity.this, HomeActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent1);
        }

    }
}
