package com.techface.gold.scheme.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.techface.gold.scheme.Adapter.SugarProdcutAdapter;
import com.techface.gold.scheme.DialogueFragment.QuantityDialogFragment;
import com.techface.gold.scheme.Helper.CommonUtils;
import com.techface.gold.scheme.Helper.Responseinfodialog;
import com.techface.gold.scheme.R;
import com.techface.gold.scheme.model.ProductList;
import com.techface.gold.scheme.network.ApiClient;
import com.techface.gold.scheme.network.ServiceGenerator;

import java.io.IOException;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity implements QuantityDialogFragment.OnFragmentInteractionListener ,Runnable{


    private final static String TAG=HomeActivity.class.getSimpleName();
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;

    @BindView(R.id.rv_product_recyclerView)
    RecyclerView mRecyclerView;

    @BindView(R.id.Tv_managepackage_empty)
    TextView mEmptyView;

    @BindView(R.id.txt_update)
     TextView mUpdate;

    @BindView(R.id.itemCount)
    TextView mItemCount;

    @BindView(R.id.ll_button_view)
    CardView mCartView;

    @BindView(R.id.toolbarLL)
    Toolbar mToolbar;


    @BindView(R.id.toolbarTextView)
    Button mBtnOverAllAmount;

    @BindView(R.id.toolbar1)
    AppBarLayout mAppBarLayout;

    @BindView(R.id.username)
    TextView mUserName;



    Button mScan, mPrint, mDisc;
    BluetoothAdapter mBluetoothAdapter;
    private UUID applicationUUID = UUID
            .fromString("00001101-0000-1000-8000-00805F9B34FB");
    private ProgressDialog mBluetoothConnectProgressDialog;
    private BluetoothSocket mBluetoothSocket;
    BluetoothDevice mBluetoothDevice;

    List<ProductList.product>mCancelList;
    private ProgressDialog mProgressdialog;
    private  AlertDialog mInfo;
    private  List<ProductList>mProductList;
    private  List<ProductList.product>mProductValue;
    private  SugarProdcutAdapter mSugarProductAdapter;
    private  List<ProductList.product>updateList =new ArrayList<>();




    private MyHandler versionHandler;
    private Runnable versionRunnable;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG,"OnCreated");
        if(savedInstanceState==null)
        {
            loadprinter();
        }
        setContentView(R.layout.activity_home);
        ButterKnife.bind(this);
        mProgressdialog = CommonUtils.getProgressDialog(HomeActivity.this);
        mCartView.setVisibility(View.GONE);
        mToolbar.setBackgroundColor(Color.parseColor("#ffffff"));
        mToolbar.setTitleTextColor((Color.parseColor("#000000")));

        mUserName.setText("ADMIN");
        //mToolbar.setTitle("Admin");
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Make toolbar show navigation button (i.e back button with arrow icon)
        mToolbar.setNavigationIcon(R.drawable.ic_arrow);
//        if (getSupportActionBar() != null) {
//
//            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow);
//            getSupportActionBar().setTitle("PRODUCT DETAILS");
//
//        }


        startVersionTimer();
        loadProduct();



        mCartView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),UpdatedListActivity.class);
                intent.putExtra("selectedList", (Serializable) updateList);
                startActivity(intent);
            }
        });

        mBtnOverAllAmount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),DailyReport.class);
                startActivity(intent);
            }
        });


    }

    private void loadprinter() {

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            Toast.makeText(HomeActivity.this, "Message1", Toast.LENGTH_SHORT).show();
        } else {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(
                        BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent,
                        REQUEST_ENABLE_BT);
            } else {
                ListPairedDevices();
                Intent connectIntent = new Intent(HomeActivity.this,
                        DeviceListActivity.class);
                startActivityForResult(connectIntent,
                        REQUEST_CONNECT_DEVICE);
            }
        }

    }

    private void ListPairedDevices() {
        Set<BluetoothDevice> mPairedDevices = mBluetoothAdapter
                .getBondedDevices();
        if (mPairedDevices.size() > 0) {
            for (BluetoothDevice mDevice : mPairedDevices) {
                Log.v(TAG, "PairedDevices: " + mDevice.getName() + "  "
                        + mDevice.getAddress());
            }
        }
    }

    private void startVersionTimer() {
        versionHandler = new MyHandler(this);
        versionRunnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "======= Version Checking Loop Started ========");
                requestIDleApI();
                versionHandler.postDelayed(this, 900000);
            }
        };
        versionHandler.postDelayed(versionRunnable, 900000);
    }

    private void requestIDleApI() {


    }

    //Get the Product Details from API
    private void loadProduct() {
        //ApiClient client = ServiceGenerator.createService(ApiClient.class, base_url);
        ApiClient service = ServiceGenerator.createService(ApiClient.class);
        Call<List<ProductList>>call=service.getProductdetail();
        mProgressdialog.show();
        call.enqueue(new Callback<List<ProductList>>() {
            @Override
            public void onResponse(Call<List<ProductList>> call, Response<List<ProductList>> response) {
                mProgressdialog.cancel();
                Log.i(TAG, "ResponseCode : " + response.code());
                Log.i(TAG, "onResponse: ---------------------------");
                Log.i(TAG, "onResponse: " + response.body());
                Log.i(TAG, "onResponse: ____________________________");
                if(response.body()!=null) {
                    loadData(response.body());
                }
                }

            @Override
            public void onFailure(Call<List<ProductList>> call, Throwable t) {
                mProgressdialog.cancel();
                if(getApplicationContext() !=null) {
                    mInfo = Responseinfodialog.alertshow(getApplicationContext(), "CONNECTION FAILURE", Color.RED);
                    mInfo.show();
                }
                t.printStackTrace();
            }
        });

    }

    private void loadData(List<ProductList> body) {
        mProductList=body;

        mProductValue=mProductList.get(0).getmProducts();
        if(mProductList.isEmpty())
        {
            mEmptyView.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.GONE);
        }
        else {
            mBtnOverAllAmount.setText("Cash In Hand");
            mEmptyView.setVisibility(View.GONE);
            mRecyclerView.setVisibility(View.VISIBLE);

            final LinearLayoutManager manager = new LinearLayoutManager(getApplicationContext());
            mRecyclerView.setLayoutManager(new GridLayoutManager(this, 1));
            mSugarProductAdapter= new SugarProdcutAdapter(getApplicationContext(),mProductList,mProductValue, new SugarProdcutAdapter.getQuantity() {
           @Override
           public void getQuantityData(String s, String s1, String s2, String s3,int s4) {
               dialogView(s,s1,s2,s3,s4);

           }
       } );


        mRecyclerView.setAdapter(mSugarProductAdapter);
        loadActivityData();

        }

    }

    private void loadActivityData() {
        if(getIntent().hasExtra("cancellist")) {
            mCancelList = (List<ProductList.product>) getIntent().getSerializableExtra("cancellist");
            Log.i(TAG,"CancelList"+mCancelList.get(0).getmProductId());

            for(int i=0;i<mCancelList.size();i++)
            {
                onFragmentInteraction(mCancelList.get(i).getmProductId(),mCancelList.get(i).getmItemName(),mCancelList.get(i).getmItemRate(),Integer.parseInt(mCancelList.get(i).getmQuantity()),mCancelList.get(i).getmTotal());
                Log.i(TAG,"CancelList"+mCancelList.get(i).getmProductId());
            }
        }
    }

    private void dialogView(String mId, String mProductName, String mItemRate, String quantity,int mTotal) {

        QuantityDialogFragment dialogue = QuantityDialogFragment.newInstance(mId,mProductName,mItemRate,quantity,mTotal);
        dialogue.setStyle(DialogFragment.STYLE_NO_FRAME, R.style.Theme_AppCompat_DayNight_Dialog_Alert);
        dialogue.show(((HomeActivity) this).getSupportFragmentManager(), "fragment_new_package");
        Log.i(TAG,mId+" -"+mProductName+"-"+mItemRate+"-"+quantity);


    }






    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();

            return true;
        }


        return super.onOptionsItemSelected(item);
    }

    public void onResume()
    {
        super.onResume();
        Log.i("onResume","Called");

    }

    @Override
    public void onFragmentInteraction(String mId, String mProductName, String mItemRate, int minteger, int update) {


        Log.i(TAG,mId+"-"+mProductName+"-"+mItemRate+"-"+minteger+"--"+update);
        mCartView.setVisibility(View.VISIBLE);
        for(int i=0;i<mProductValue.size();i++) {
            if (mProductValue.get(i).getmProductId().equals(mId)) {
                mProductValue.get(i).setmQuantity(String.valueOf(minteger));
                mProductValue.get(i).setmTotal(update);
                break;


            }
        }

        mSugarProductAdapter.notifyDataSetChanged();

        if(updateList.isEmpty())
        {
            updateList.add(new ProductList.product(mId,mProductName,mItemRate,String.valueOf(minteger),update));
        }else if(1==LoadUpdateValue(mId,minteger)) {

            for (int i = 0; i <updateList.size(); i++) {

                if (updateList.get(i).getmProductId().equals(mId)) {


                    updateList.get(i).setmQuantity(String.valueOf(minteger));
                    updateList.get(i).setmTotal(update);

                    break;


                }
            }

        }
        else {
            updateList.add(new ProductList.product(mId,mProductName,mItemRate,String.valueOf(minteger),update));
        }

       loadData1();





    }

    private int LoadUpdateValue(String mId, int minteger) {
        for (int i = 0; i <updateList.size(); i++) {

            if (updateList.get(i).getmProductId().equals(mId)) {
                return 1;
                }
        }
        return 0;
    }

    private void loadData1() {
        Log.i(TAG,"LIST SIZE "+updateList.size());
        mItemCount.setText(String .valueOf(updateList.size())+" Items");
        int mTotal=0;
        for(int i=0;i<updateList.size();i++)
        {

            Log.i(TAG,"ID: "+String.valueOf(updateList.get(i).getmProductId()+" ITEMRATE: "+updateList.get(i).getmItemRate()+" ITEM QUANTITY: "+updateList.get(i).getmQuantity()+"TOTAL: "+updateList.get(i).getmTotal()));
           mTotal+=updateList.get(i).getmTotal();
        }
        mUpdate.setText("Total : ₹"+String.valueOf(mTotal));
    }


    private static class MyHandler extends Handler {
        private final WeakReference<HomeActivity> mActivity;

        public MyHandler(HomeActivity activity) {

            mActivity = new WeakReference<>(activity);
        }
    }

    public void onActivityResult(int mRequestCode, int mResultCode,
                                 Intent mDataIntent) {
        super.onActivityResult(mRequestCode, mResultCode, mDataIntent);

        switch (mRequestCode) {
            case REQUEST_CONNECT_DEVICE:
                if (mResultCode == Activity.RESULT_OK) {
                    Bundle mExtra = mDataIntent.getExtras();
                    String mDeviceAddress = mExtra.getString("DeviceAddress");
                    Log.v(TAG, "Coming incoming address " + mDeviceAddress);
                    mBluetoothDevice = mBluetoothAdapter
                            .getRemoteDevice(mDeviceAddress);
                    mBluetoothConnectProgressDialog = ProgressDialog.show(this,
                            "Connecting...", mBluetoothDevice.getName() + " : "
                                    + mBluetoothDevice.getAddress(), true, false);
                   //
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            // closeSocket(mBluetoothSocket);
                            Toast.makeText(HomeActivity.this, "Device Not Connected", Toast.LENGTH_SHORT).show();
                            mBluetoothConnectProgressDialog.dismiss();
                            // Actions to do after 5 seconds
                        }
                    }, 10000);
                   Thread mBlutoothConnectThread = new Thread();
                    mBlutoothConnectThread.start();
                    // pairToDevice(mBluetoothDevice); This method is replaced by
                    // progress dialog with thread
                }
                break;

            case REQUEST_ENABLE_BT:
                if (mResultCode == Activity.RESULT_OK) {
                    ListPairedDevices();
                    Intent connectIntent = new Intent(HomeActivity.this,
                            DeviceListActivity.class);
                    startActivityForResult(connectIntent, REQUEST_CONNECT_DEVICE);
                } else {
                    Toast.makeText(HomeActivity.this, "Message", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }


    public void run() {
        try {
            mBluetoothSocket = mBluetoothDevice
                    .createRfcommSocketToServiceRecord(applicationUUID);
            mBluetoothAdapter.cancelDiscovery();
            mBluetoothSocket.connect();
            mHandler.sendEmptyMessage(0);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                   // closeSocket(mBluetoothSocket);
                    mBluetoothConnectProgressDialog.dismiss();
                    // Actions to do after 5 seconds
                }
            }, 10000);
        } catch (IOException eConnectException) {
            Log.d(TAG, "CouldNotConnectToSocket", eConnectException);
            closeSocket(mBluetoothSocket);
            return;
        }
    }

    private void closeSocket(BluetoothSocket nOpenSocket) {
        try {
            nOpenSocket.close();
            Log.d(TAG, "SocketClosed");
        } catch (IOException ex) {
            Log.d(TAG, "CouldNotCloseSocket");
        }
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            mBluetoothConnectProgressDialog.dismiss();
            Toast.makeText(HomeActivity.this, "DeviceConnected", Toast.LENGTH_SHORT).show();
        }
    };
}
