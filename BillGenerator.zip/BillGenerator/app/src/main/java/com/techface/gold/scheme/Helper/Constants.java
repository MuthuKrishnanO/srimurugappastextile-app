package com.techface.gold.scheme.Helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class Constants {

    public static final String ANDROID_ID = "androidId";
    public static final String DEVICE_ID = "deviceId";
    public static final String PRODUCT_ID = "product_id";
    public static  final String USERNAME="username";
    public  static final String PASSWORD ="password";
    public  static final String UserId="userid";
    private static Constants mConstants;


    public static final String SERVERURL = "https://api.myjson.com";


    private static final String BASE_URL_KEY = "base_url";


    public static Constants getInstance() {

        if (mConstants == null) {
            mConstants = new Constants();
        }
        return mConstants;
    }

    public String getBASE_URL(Context context) {

        SharedPreferences sP = PreferenceManager.getDefaultSharedPreferences(context);
        String str = sP.getString(BASE_URL_KEY, "");
        return str;
    }

    public void setBASE_URL(String baseUrl, Context context) {

        SharedPreferences sP = PreferenceManager.getDefaultSharedPreferences(context);
        String str = sP.getString(BASE_URL_KEY, "");
        if (!str.equals("") || !str.equals(baseUrl)) {
            SharedPreferences.Editor edit = sP.edit();
            edit.putString(BASE_URL_KEY, baseUrl);
            edit.apply();
        }
    }
}
