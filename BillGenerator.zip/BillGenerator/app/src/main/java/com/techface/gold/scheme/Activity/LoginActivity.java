package com.techface.gold.scheme.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.support.design.widget.Snackbar;
import android.widget.Toast;

import com.techface.gold.scheme.Helper.ConnectivityReceiver;
import com.techface.gold.scheme.Helper.Constants;
import com.techface.gold.scheme.R;

public class LoginActivity extends AppCompatActivity implements TextWatcher,
        CompoundButton.OnCheckedChangeListener,ActivityCompat.OnRequestPermissionsResultCallback,
        ConnectivityReceiver.ConnectivityReceiverListener {

    private final static String TAG=LoginActivity.class.getSimpleName();
    private EditText etUsername, etPass;
    private TextView mAndroidId;
    private  View mMainLayout;
    private Button mLogin;
    private TextView mSignup;
    private ConnectivityReceiver mReceiver;
    private CheckBox rem_userpass;
    private static final String PREF_NAME = "prefs";
    private static final String KEY_REMEMBER = "remember";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASS = "password";
    public static final int READ_PHONE_REQUEST_CODE = 1112;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        String packageName = getApplicationContext().getPackageName();
        System.out.println(" PACKAGE NAME ====>  " + packageName);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        mMainLayout=(View)findViewById(R.id.main_layout);
        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        etUsername = (EditText)findViewById(R.id.user_name_et);
        etPass = (EditText)findViewById(R.id.pass_word_et);
        mAndroidId=(TextView)findViewById(R.id.tv_android_id);
        rem_userpass = (CheckBox)findViewById(R.id.show_hide_password);
        mSignup=(TextView)findViewById(R.id.signup);
        mLogin=(Button)findViewById(R.id.btn_login);
        checkRunTimePermissions();
        mReceiver = new ConnectivityReceiver();

        if(sharedPreferences.getBoolean(KEY_REMEMBER, false))
            rem_userpass.setChecked(true);
        else
            rem_userpass.setChecked(false);

        etUsername.setText(sharedPreferences.getString(KEY_USERNAME,""));
        etPass.setText(sharedPreferences.getString(KEY_PASS,""));

        etUsername.addTextChangedListener(this);
        etPass.addTextChangedListener(this);
        rem_userpass.setOnCheckedChangeListener(this);

        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkConnectivity()) {
                    if (!etUsername.getText().toString().isEmpty() && !etUsername.getText().toString().isEmpty()) {
                        if (etUsername.getText().toString().equals("admin") && etUsername.getText().toString().equals("admin")) {

                            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                            startActivity(intent);

                        } else {
                            Toast.makeText(getApplicationContext(), "UserName and Password Is Failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Empty field", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(LoginActivity.this, "Check Your Internet !!!",
                            Toast.LENGTH_LONG).show();
                }
            }
        });


        mSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }



    private void checkRunTimePermissions() {

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            saveAndroidId();
        } else {
            requestPermission();
        }
    }

    private void requestPermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.READ_PHONE_STATE)) {

            Snackbar.make(mMainLayout, "Device Id Access is Required !!",
                    Snackbar.LENGTH_INDEFINITE).setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ActivityCompat.requestPermissions(LoginActivity.this,
                            new String[]{Manifest.permission.READ_PHONE_STATE},
                            READ_PHONE_REQUEST_CODE);
                }
            }).show();
        } else {
            /*initial user permission grant*/
            Snackbar.make(mMainLayout, "Device Id Access is Required !!",
                    Snackbar.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(LoginActivity.this,
                    new String[]{Manifest.permission.READ_PHONE_STATE},
                    READ_PHONE_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == READ_PHONE_REQUEST_CODE) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveAndroidId();

            } else {

                Snackbar.make(mMainLayout, "Device Id Permission is Denied!!",
                        Snackbar.LENGTH_SHORT).show();
            }
        }
    }

    private void saveAndroidId() {


            @SuppressLint("HardwareIds")

            String androidId = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
            Log.i(TAG, "Android Id: " + androidId);
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

            @SuppressLint({"MissingPermission", "HardwareIds"})
            String deviceId = telephonyManager != null ? telephonyManager.getDeviceId() : null;

            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
            editor.putString(Constants.ANDROID_ID, androidId);
            editor.putString(Constants.DEVICE_ID, deviceId);

            editor.apply();
            mAndroidId.setText(androidId + " : " + deviceId);

            // mDeviceId.setText(deviceId);

    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        managePrefs();
    }

    @Override
    public void afterTextChanged(Editable s) {

    }



    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        managePrefs();
    }

    private void managePrefs(){
        if(rem_userpass.isChecked()){
            editor.putString(KEY_USERNAME, etUsername.getText().toString().trim());
            editor.putString(KEY_PASS, etPass.getText().toString().trim());
            editor.putBoolean(KEY_REMEMBER, true);
            editor.apply();
        }else{
            editor.putBoolean(KEY_REMEMBER, false);
            editor.remove(KEY_PASS);//editor.putString(KEY_PASS,"");
            editor.remove(KEY_USERNAME);//editor.putString(KEY_USERNAME, "");
            editor.apply();
        }
    }


    private boolean checkConnectivity() {

        ConnectivityManager manager = (ConnectivityManager) getApplicationContext().getSystemService(
                Context.CONNECTIVITY_SERVICE);
        assert manager != null;
        NetworkInfo info = manager.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    @Override
    public void onNetworkChanged(boolean isConnected) {

    }



}
