package com.techface.gold.scheme.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.techface.gold.scheme.R;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}